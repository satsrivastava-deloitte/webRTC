export type WebRTCUser = {
	id: string;
	email: string;
	stream: MediaStream;
};
